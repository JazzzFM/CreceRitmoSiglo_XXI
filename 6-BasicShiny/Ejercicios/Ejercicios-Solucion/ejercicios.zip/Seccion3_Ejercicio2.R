"
2 - Dibuja el grafo reactivo para las siguientes funciones de servidor:
"
# ----------------------------------------------
# server1 <- function(input, output, session) {
#   c <- reactive(input$a + input$b)
#   e <- reactive(c() + input$d)
#   output$f <- renderText(e())
# }
# server2 <- function(input, output, session) {
#   x <- reactive(input$x1 + input$x2 + input$x3)
#   y <- reactive(input$y1 + input$y2)
#   output$z <- renderText(x() / y())
# }
# server3 <- function(input, output, session) {
#   d <- reactive(c() ^ input$d)
#   a <- reactive(input$a * 10)
#   c <- reactive(b() / input$c) 
#   b <- reactive(a() + input$b)
# }
# ----------------------------------------------

# Resolución del problema ----------------------------------------------
