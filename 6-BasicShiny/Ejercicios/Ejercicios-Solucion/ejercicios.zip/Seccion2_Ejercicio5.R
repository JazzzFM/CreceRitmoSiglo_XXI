# Planteamiento del problema ----------------------------------------------
"
1 - ¿Con cuál de `textOutput()` y `verbatimTextOutput()` se debe emparejar
    cada una de las siguientes funciones de renderizado?

    * a) `renderPrint(summary(mtcars))`
    * b) `renderText('Good morning!')`
    * c) `renderPrint(t.test(1:5, 2:6))`
    * d) `renderText(str(lm(mpg ~ wt, data = mtcars)))`
"
# Resolución del problema ----------------------------------------------
